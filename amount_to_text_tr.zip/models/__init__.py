# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
#
# Copyright (c) 2018  - Raiden - www.raiden.com.tr

import amount_to_text_tr
